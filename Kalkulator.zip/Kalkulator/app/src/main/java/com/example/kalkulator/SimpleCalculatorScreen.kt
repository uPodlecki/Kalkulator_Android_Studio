package com.example.kalkulator

import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SimpleCalculatorScreen(viewModel: CalculatorViewModel) {
    Column(modifier = Modifier
        .fillMaxSize()
        .systemBarsPadding(), verticalArrangement = Arrangement.Center) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(2f),
            contentAlignment = Alignment.BottomEnd,
        )
        {
            Text(
                modifier = Modifier
                    .padding(16.dp)
                    .horizontalScroll(rememberScrollState()),
                maxLines = 1,
                fontSize = 60.sp,
                text = viewModel.currentInput.ifEmpty { "0" }
            )
        }
        val context = LocalContext.current
        val numberColor = Color(0xFF333333)
        val actionColor = Color(0xFFA5A5A5)
        val operatorColor = Color(0xFFFF9500)
        Row(modifier = Modifier
            .fillMaxWidth()
            .weight(1f)) {
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = actionColor, contentColor = Color.Black),
                onClick = { viewModel.onDeleteClick() }) { AutoSizeText("Del") }
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = actionColor, contentColor = Color.Black),
                onClick = { viewModel.onClearClick() }) { AutoSizeText("AC") }
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = actionColor, contentColor = Color.Black),
                onClick = { viewModel.onClearEntryClick() }) { AutoSizeText("C") }
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = operatorColor, contentColor = Color.White),
                onClick = { viewModel.onOperatorClick("/") }) { AutoSizeText("/") }
            Spacer(modifier = Modifier.height(16.dp))
        }
        Row(modifier = Modifier
            .fillMaxWidth()
            .weight(1f)) {
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = numberColor, contentColor = Color.White),
                onClick = { viewModel.onNumberCLick("7") }) { AutoSizeText("7") }
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = numberColor, contentColor = Color.White),
                onClick = { viewModel.onNumberCLick("8") }) { AutoSizeText("8") }
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = numberColor, contentColor = Color.White),
                onClick = { viewModel.onNumberCLick("9") }) { AutoSizeText("9") }
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = operatorColor, contentColor = Color.White),
                onClick = { viewModel.onOperatorClick("X") }) { AutoSizeText("X") }
        }
        Row(modifier = Modifier
            .fillMaxWidth()
            .weight(1f)) {
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = numberColor, contentColor = Color.White),
                onClick = { viewModel.onNumberCLick("4") }) { AutoSizeText("4") }
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = numberColor, contentColor = Color.White),
                onClick = { viewModel.onNumberCLick("5") }) { AutoSizeText("5") }
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = numberColor, contentColor = Color.White),
                onClick = { viewModel.onNumberCLick("6") }) { AutoSizeText("6") }
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = operatorColor, contentColor = Color.White),
                onClick = { viewModel.onOperatorClick("-") }) { AutoSizeText("-") }
        }
        Row(modifier = Modifier
            .fillMaxWidth()
            .weight(1f)) {
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = numberColor, contentColor = Color.White),
                onClick = { viewModel.onNumberCLick("1") }) { AutoSizeText("1") }
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = numberColor, contentColor = Color.White),
                onClick = { viewModel.onNumberCLick("2") }) { AutoSizeText("2") }
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = numberColor, contentColor = Color.White),
                onClick = { viewModel.onNumberCLick("3")}) { AutoSizeText("3") }
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = operatorColor, contentColor = Color.White),
                onClick = { viewModel.onOperatorClick("+") }) { AutoSizeText("+") }
        }
        Row(modifier = Modifier
            .fillMaxWidth()
            .weight(1f)) {
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = actionColor, contentColor = Color.Black),
                onClick = { viewModel.onChangeSignClick() }) { AutoSizeText("+/-") }
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = numberColor, contentColor = Color.White),
                onClick = { viewModel.onNumberCLick("0") }) { AutoSizeText("0") }
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = actionColor, contentColor = Color.Black),
                onClick = { viewModel.onDecimalClick()}) { AutoSizeText(".") }
            Button(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .padding(4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = operatorColor, contentColor = Color.White),
                onClick = { if(viewModel.operator=="/" && viewModel.currentInput.toDoubleOrNull()==0.0) {
                    Toast.makeText(context,"Nie dziel przez 0!", Toast.LENGTH_SHORT).show()
                    viewModel.onClearClick()
                }
                else{
                    viewModel.onEqualsClick()
                } }) { AutoSizeText("=") }
        }
    }
}