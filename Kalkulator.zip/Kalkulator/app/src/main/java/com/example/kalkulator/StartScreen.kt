package com.example.kalkulator

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun StartScreen(navController: NavController) {
    val activity = LocalContext.current as android.app.Activity
    Column(modifier = Modifier
        .fillMaxSize()
        .systemBarsPadding(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {AutoSizeText("My calculator")
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            modifier = Modifier.fillMaxWidth(0.6f).height(60.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9500), contentColor = Color.Black ) ,
            onClick = {navController.navigate("simple")}) {AutoSizeText("Simple calculator") }
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            modifier = Modifier.fillMaxWidth(0.6f).height(60.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9500), contentColor = Color.Black ) ,
            onClick = {navController.navigate("advanced")}) {AutoSizeText("Advanced calculator") }
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            modifier = Modifier.fillMaxWidth(0.6f).height(60.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9500), contentColor = Color.Black ) ,
            onClick = {navController.navigate("about")}) {AutoSizeText("About app") }
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            modifier = Modifier.fillMaxWidth(0.6f).height(60.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9500), contentColor = Color.Black ) ,
            onClick = {activity.finish()}) {AutoSizeText("Exit") }}
}
