package com.example.kalkulator

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

class CalculatorViewModel : ViewModel() {
    var currentInput by mutableStateOf("")
    var previousInput: String = ""
    var operator: String = ""
    fun onNumberCLick(number: String){
        currentInput+=number
    }
    fun onClearClick(){
        currentInput=""
        previousInput=""
        operator=""
    }
    fun onOperatorClick(op: String){
        previousInput = currentInput
        operator = op
        currentInput = ""
    }
    fun onEqualsClick(){
        val num1 = previousInput.toDoubleOrNull()
        val num2 = currentInput.toDoubleOrNull()
        if(num1 != null && num2 !=null){
            when(operator){
                "+"->currentInput = (num1 + num2).toString()
                "-"->currentInput = (num1 - num2).toString()
                "X"->currentInput = (num1 * num2).toString()
                "/"->currentInput = (num1 / num2).toString()
                "x^y"->currentInput = num1.pow(num2).toString()
            }
            previousInput = ""
            operator = ""
        }
    }
    fun onSquareClick(){
        val num = currentInput.toDoubleOrNull()
        if(num!=null){
            currentInput = num.pow(2).toString()
        }
    }
    fun onSinusClick(){
        val num = currentInput.toDoubleOrNull()
        if(num!=null){
            currentInput = sin(Math.toRadians(num)).toString()
        }
    }
    fun onCosinusClick(){
        val num = currentInput.toDoubleOrNull()
        if(num!=null){
            currentInput = cos(Math.toRadians(num)).toString()
        }
    }
    fun onTangensClick(){
        val num = currentInput.toDoubleOrNull()
        if(num!=null){
            currentInput = tan(Math.toRadians(num)).toString()
        }
    }
    fun onSqrtClick(){
        val num = currentInput.toDoubleOrNull()
        if(num!=null){
            currentInput = sqrt(num).toString()
        }

    }
    fun onLnClick(){
        val num = currentInput.toDoubleOrNull()
        if(num!=null){
            currentInput = ln(num).toString()
        }
    }
    fun onLogClick(){
        val num = currentInput.toDoubleOrNull()
        if(num!=null){
            currentInput = log10(num).toString()
        }
    }
    fun onPercentClick(){
        val num = currentInput.toDoubleOrNull()
        if(num!=null){
            currentInput = (num/100).toString()
        }
    }
    fun onDeleteClick(){
        currentInput = currentInput.dropLast(1)
    }
    fun onDecimalClick(){
        if(!currentInput.contains(".")){
            currentInput+="."
        }
    }
    fun onChangeSignClick(){
        if(currentInput.isNotEmpty()){
            if(currentInput.startsWith("-")){
                currentInput = currentInput.drop(1)
            }else{
                currentInput = "-" + currentInput
            }
        }
    }
    fun onClearEntryClick(){
        if(currentInput.isEmpty()){
            onClearClick()
        }else{
            currentInput=""
        }
    }

}