package com.example.kalkulator

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun AboutScreen(navController: NavController) {
    Column(modifier = Modifier
        .fillMaxSize()
        .systemBarsPadding(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        AutoSizeText(modifier = Modifier.padding(8.dp), text = "Informacje o aplikacji i autorze:")
        AutoSizeText(modifier = Modifier.padding(8.dp), text = "Aplikacja: Kalkulator do prostych oraz bardziej złożonych obliczeń")
        AutoSizeText(modifier = Modifier.padding(8.dp), text = "Autor: Marcel Podlecki Student 3 roku Informatyki")
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray, contentColor = Color.White),
            onClick = { navController.navigate("start") }) { AutoSizeText("Back to menu") }
    }
}